package test;


import org.junit.Ignore;
import org.junit.jupiter.api.Test;

import uk.ac.uos.i2p.S211621.part2.CommandLineApplication;

class CommandLineApplicationTest {

	//@Ignore
	@Test
	/**
	 * Test for contacts file created  if student is Covid +ve
	 * Manual process : Uncomment Ignore and put @Test in case you are running testCovidNegativeContacts
	 * post this test , please deleted the created files 
	 * @throws Exception
	 */
    public void testCovidPositiveContacts() throws Exception{
        CommandLineApplication.main(new String[] { "S101", "Positive", "tests.csv", "contacts.csv"});

    }

	/**
	 * Test for contacts file not created  if student is Covid -ve
	 * Manual process :Uncomment Ignore and put @Test in case you are running testCovidPositiveContacts
	 * post this test , please deleted the created files 
	 * @throws Exception
	 */
	//@Test
	@Ignore
    public void testCovidNegativeContacts() throws Exception{
        CommandLineApplication.main(new String[] { "S101", "Negative", "tests.csv", "contacts.csv"});

    }

}
