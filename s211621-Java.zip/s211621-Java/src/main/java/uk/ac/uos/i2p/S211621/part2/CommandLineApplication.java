
package uk.ac.uos.i2p.S211621.part2;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import uk.ac.uos.i2p.S211621.part1.MemoryContactTracer;
import uk.ac.uos.i2p.assignment.ContactTracer;

public class CommandLineApplication {

	static String datePattern = "yyyy-MM-dd";
	static String timePattern = "HH:mm:ss";

	static SimpleDateFormat simpleDateFormatDatePattern = new SimpleDateFormat(datePattern);
	static SimpleDateFormat simpleDateFormatTimePattern = new SimpleDateFormat(timePattern);

	public static void main(String[] args) throws Exception {

		// checkArguments(args);
		if (args.length < 4) {

		}

		String studentId = args[0];
		String testResults = args[1];
		String testResultsCSVFileName = args[2];
		String contactsCSVFileName = args[3];

//		args = S101 Positive, tests.csv results.csv 
		ContactTracer tracer = loadDataForEnrollment();

		createCSVFileForTestResults(testResultsCSVFileName, tracer, studentId, testResults);

		if (testResults.equalsIgnoreCase("Positive")) {
			List<String> studentsIdsInContact = tracer.findContacts(studentId);

			createCSVFileForContacts(contactsCSVFileName, tracer, testResults, studentsIdsInContact);
		}

	}

	private static ContactTracer loadDataForEnrollment() {
		ContactTracer tracer = new MemoryContactTracer();

		tracer.addCourse("SOFT01", "Software Engineering");
		tracer.addCourse("NET02", "Network Engineering");
		tracer.addCourse("CYB03", "Cyber Security");

		tracer.addStudent("S101", "Clint Eastwood", "abc@uos.ac.uk");
		tracer.addStudent("S102", "Jamie Foxx", "xyz@uos.ac.uk");
		tracer.addStudent("S103", "Olivia Wilde", "klm@uos.ac.uk");
		tracer.addStudent("S104", "Vishal Gupta", "vg@uos.ac.uk");
		tracer.addStudent("S105", "Michael Jackson", "mj@uos.ac.uk");
		tracer.addStudent("S106", "Shawn Davis", "sd@uos.ac.uk");
		tracer.addStudent("S107", "John Doe", "jd@uos.ac.uk");
		tracer.addStudent("S108", "Fed Baker", "fb@uos.ac.uk");
		tracer.addStudent("S109", "Phil Smith", "ps@uos.ac.uk");

		tracer.addStudent("S110", "Harry Potter", "hp@uos.ac.uk");
		tracer.addStudent("S111", "Steve fleming", "sf@uos.ac.uk");
		tracer.addStudent("S112", "Martin Flower", "mf@uos.ac.uk");

		Map<String, String> enrolments = new HashMap<>();
		enrolments.put("S101", "SOFT01");
		enrolments.put("S103", "SOFT01");
		enrolments.put("S104", "SOFT01");
		enrolments.put("S105", "SOFT01");

		enrolments.put("S102", "NET02");
		enrolments.put("S106", "NET02");
		enrolments.put("S107", "NET02");

		enrolments.put("S110", "CYB03");
		enrolments.put("S111", "CYB03");
		enrolments.put("S112", "CYB03");

		// 108 and 109 not enrolled in any of the courses

		tracer.loadStudentCourseList(enrolments);
		return tracer;
	}

	private static void createCSVFileForTestResults(String testResultsCSVFileName, ContactTracer tracer,
			String studentId, String testResults) {

		String testResultString = tracer.getStudentName(studentId) + "," + studentId + "," + testResults + ","
				+ simpleDateFormatDatePattern.format(new Date()) + "," + simpleDateFormatTimePattern.format(new Date());

		File csvOuputFile = new File(testResultsCSVFileName);

		FileWriter csvTestResultFile = null;
		try {
			csvTestResultFile = new FileWriter(csvOuputFile, true);
			csvTestResultFile.append(testResultString);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				csvTestResultFile.flush();
				csvTestResultFile.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		System.out.println("Test Results created in file results.csv");

	}

	private static void createCSVFileForContacts(String contactsCSVFileName, ContactTracer tracer, String testResults,
			List<String> studentsIdsInContact) throws IOException {

		File csvOuputFile = new File(contactsCSVFileName);

		FileWriter csvTestResultFile = null;
		try {

			csvTestResultFile = new FileWriter(csvOuputFile, true);

			for (int i = 0; i < studentsIdsInContact.size(); i++) {
				String contact = tracer.getStudentName(studentsIdsInContact.get(i)) + "," + studentsIdsInContact.get(i)
						+ "," + testResults + "," + simpleDateFormatDatePattern.format(new Date()) + ","
						+ simpleDateFormatTimePattern.format(new Date());

				csvTestResultFile.append(contact + "\n");
			}
			csvTestResultFile.flush();
			csvTestResultFile.close();
		} finally {

			System.out.println("Test Results output has been created in contacts.csv");

		}
	}
}
