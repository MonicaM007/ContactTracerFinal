package uk.ac.uos.i2p.S211621.part3;

import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JOptionPane;

public class GUIApplication {

	private static Object testResultsCSVFileName;
	private static Object tracer;
	private static Object studentId;
	private static Object testResults;

	@SuppressWarnings("unused")
	public static void main(String[] args) {

		String studentID = "output/tests.csv";
		String testResult = "output/results.csv";

		studentID = JOptionPane.showInputDialog("Student ID");

		JOptionPane.showInputDialog("Test Result");

		createCSVFileForTestResults(testResultsCSVFileName, tracer, studentId, testResults);

	}

	FileWriter csvTestResultFile = null;
	private String csvOuputFile;
	{

		try {
			csvTestResultFile = new FileWriter(csvOuputFile, true);
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			csvTestResultFile.append(studentId + "\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
		// reads file and stores in reader.
	}

	private static void createCSVFileForTestResults(Object testResultsCSVFileName, Object tracer, Object studentId,
			Object testResults) {
	}

}
